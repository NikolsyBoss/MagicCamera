package com.seu.magicfilter.filter.advanced;

import com.seu.magicfilter.MagicEngine;
import com.seu.magicfilter.filter.base.MagicLookupFilter;

public class MagicFairytaleFilter extends MagicLookupFilter{

	public MagicFairytaleFilter() {
		super("filter/fairy_tale.png");
	}
}
