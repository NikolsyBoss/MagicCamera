package com.seu.magicfilter.camera.utils;

/**
 * Created by why8222 on 2016/2/25.
 */
public class CameraInfo {

    public int previewWidth;

    public int previewHeight;

    public int orientation;

    public boolean isFront;

    public int pictureWidth;

    public int pictureHeight;
}
