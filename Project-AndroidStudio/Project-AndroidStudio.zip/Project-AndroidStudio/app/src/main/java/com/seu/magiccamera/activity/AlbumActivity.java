package com.seu.magiccamera.activity;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by why8222 on 2016/3/18.
 */
public class AlbumActivity extends Activity{


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
}
